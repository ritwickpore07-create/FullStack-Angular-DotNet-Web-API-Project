export interface User
{
    email: string;
    roles: string[];
}