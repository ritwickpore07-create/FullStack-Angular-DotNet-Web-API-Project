import { Component, OnDestroy, OnInit } from '@angular/core';
import { AddblogPost } from '../models/add-blog-post.model';
import { BlogPostService } from '../services/blog-post.service';
import { Router } from '@angular/router';
import { CategoryService } from '../../category/services/category.service';
import { Observable, Subscription } from 'rxjs';
import { Category } from '../../category/model/category.model';
import { ImageService } from 'src/app/shared/components/image-selector/image.service';

@Component({
  selector: 'app-add-blogpost',
  templateUrl: './add-blogpost.component.html',
  styleUrls: ['./add-blogpost.component.css']
})
export class AddBlogpostComponent implements OnInit, OnDestroy {
  model: AddblogPost;
  isImageSelectorVisible: boolean = false;
  category$?: Observable<Category[]>;
  imageSelectSubscription?: Subscription;

  constructor(private blogpostService: BlogPostService,
    private router: Router,
    private categoryService: CategoryService,
    private imageService: ImageService) {
    this.model =
    {
      title: '',
      urlHandle: '',
      shortDescription: '',
      content: '',
      featuredImageUrl: '',
      author: '',
      publishDate: new Date(),
      isVisible: true,
      categories: []
    };
  }
  
  ngOnInit(): void {
    this.category$ = this.categoryService.getAllCategories();
    this.imageSelectSubscription = this.imageService.onSelectImage()
      .subscribe({
        next: (response) => {
          if (this.model) {
            this.model.featuredImageUrl = response.url;
            this.isImageSelectorVisible = false;
          }
        }
      });
  }

  onFormSubmit(): void {
    console.log(this.model);
    this.blogpostService.createBlogPost(this.model)
      .subscribe({
        next: (response) => {
          this.router.navigateByUrl('/admin/blogposts');
        },
        error: (err) => console.error('Error adding blog-post:', err)
      });
  }

  onImageSelector(): void {
    this.isImageSelectorVisible = true;
  }

  closeImageSelector(): void {
    this.isImageSelectorVisible = false;
  }

  ngOnDestroy(): void {
    this.imageSelectSubscription?.unsubscribe();
  }
}
