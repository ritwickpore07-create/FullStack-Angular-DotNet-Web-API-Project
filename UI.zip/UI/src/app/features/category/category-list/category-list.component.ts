import { Component, OnInit } from '@angular/core';
import { Category } from '../model/category.model';
import { Observable, of } from 'rxjs';
import { CategoryService } from '../services/category.service';

@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit {

  categories$?: Observable<Category[]>;
  totalCount?: number;
  list: number[] = [];
  pageNumber = 1;
  pageSize = 4;

  constructor(private categoryservice: CategoryService) { }

  ngOnInit(): void {
    this.categoryservice.getCategoryCount()
      .subscribe({
        next: (value) => {
          this.totalCount = value;
          this.list = new Array(Math.ceil(value / this.pageSize));
        }
      });

    this.categories$ = this.categoryservice.getAllCategories(
      undefined,
      undefined,
      undefined,
      this.pageNumber,
      this.pageSize
    );

    this.categories$.subscribe(data => {
      console.log('Fetched categories:', data);
    });
  }

  onSearch(query: string) {
    //alert(query);
    this.categories$ = this.categoryservice.getAllCategories(query);
  }

  sort(sortBy: string, sortDirection: string) {
    this.categories$ = this.categoryservice.getAllCategories(undefined, sortBy, sortDirection);
  }

  getPage(pageNumber: number) {
    this.pageNumber = pageNumber;

    this.categories$ = this.categoryservice.getAllCategories(
      undefined,
      undefined,
      undefined,
      this.pageNumber,
      this.pageSize
    );
  }

  getPreviousPage() {
    if (this.pageNumber - 1 < 1) {
      return;
    }
    this.pageNumber = this.pageNumber - 1;
    this.categories$ = this.categoryservice.getAllCategories(
      undefined,
      undefined,
      undefined,
      this.pageNumber,
      this.pageSize
    );
  }

  getNextPage() {
    if (this.pageNumber + 1 > this.list.length) {
      return;
    }
    this.pageNumber = this.pageNumber + 1;
    this.categories$ = this.categoryservice.getAllCategories(
      undefined,
      undefined,
      undefined,
      this.pageNumber,
      this.pageSize
    );
  }
}

/* ngOnInit(): void {
    this.categories$ = of([
      { id: '1', name: 'UI', urlHandle: 'ui' },
      { id: '2', name: 'Backend', urlHandle: 'backend' }
    ]);

    this.categories$.subscribe(data => {
      console.log('Fetched categories (dummy):', data);
    }); 
  } */
