﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace CodePulse.API.Data
{
    public class AuthDbContext : IdentityDbContext
    {
        public AuthDbContext(DbContextOptions<AuthDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            var readerRoleId = "331ad58b-0c09-49ba-a16b-1fe18596fb61";
            var writerRoleId = "76580e62-5a6d-4c4e-944a-12b0c4a0b0fe";

            // Create reader & writer role and Seed the roles
            builder.Entity<IdentityRole>().HasData(
            new IdentityRole
            {
                Id = readerRoleId,
                Name = "Reader",
                NormalizedName = "READER",
                ConcurrencyStamp = readerRoleId
            },
            new IdentityRole
            {
                Id = writerRoleId,
                Name = "Writer",
                NormalizedName = "WRITER",
                ConcurrencyStamp = writerRoleId
            });

            // Create an Admin User
            var adminUserId = "7ece799d-1d02-4bb6-a285-cce49936d862";
            var admin = new IdentityUser()
            {
                Id = adminUserId,
                UserName = "admin@codepulse.com",
                Email = "admin@codepulse.com",
                NormalizedEmail = "admin@codepulse.com".ToUpper(),
                NormalizedUserName = "admin@codepulse.com".ToUpper(),
                //PasswordHash = "AQAAAAIAAYagAAAAEMBf9DCRymgfY76e0HYtChLKUBXed+1p0JUNSE2ztD7AfGIaYEa8ovz7VkRYr652cw==",
                SecurityStamp = "STATIC-SECURITY-STAMP", 
                ConcurrencyStamp = "STATIC-CONCURRENCY-STAMP"
            };

            admin.PasswordHash = new PasswordHasher<IdentityUser>().HashPassword(admin, "Admin@123#");            
            builder.Entity<IdentityUser>().HasData(admin);

            // Give Roles to Admin and seed
            builder.Entity<IdentityUserRole<string>>().HasData(
            new IdentityUserRole<string>
            {
                UserId = adminUserId,
                RoleId = readerRoleId
            },
            new IdentityUserRole<string>
            {
                UserId = adminUserId,
                RoleId = writerRoleId
            });
        }
    }
}
