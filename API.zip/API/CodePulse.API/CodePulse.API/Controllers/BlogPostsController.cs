﻿using Azure.Core;
using CodePulse.API.Models.Domain;
using CodePulse.API.Models.DTO;
using CodePulse.API.Repositories.Implementation;
using CodePulse.API.Repositories.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CodePulse.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BlogPostsController : ControllerBase
    {
        private readonly IBlogPostRepository _blogpostRepository;
        private readonly ICategoryRepository _categoryRepository;
        public BlogPostsController(IBlogPostRepository blogpostRepository, ICategoryRepository categoryRepository)
        {
            _blogpostRepository = blogpostRepository;
            _categoryRepository = categoryRepository;
        }

        //POST: https://localhost:7154/api/blogposts
        [HttpPost]
        [Authorize(Roles = "Writer")]
        public async Task<IActionResult> CreateBlogPost([FromBody] CreateBlogPostRequestDto request)
        {
            // Convert DTO to Domain 
            var blogPost = new BlogPost
            {
                Title = request.Title,
                ShortDescription = request.ShortDescription,
                Content = request.Content,
                FeaturedImageUrl = request.FeaturedImageUrl,
                UrlHandle = request.UrlHandle,
                PublishDate = request.PublishDate,
                Author = request.Author,
                IsVisible = request.IsVisible,
                Categories = new List<Category>()
            };
            foreach (var categoryGuid in request.Categories)
            {
                var esistingCategory = await _categoryRepository.GetById(categoryGuid);
                if (esistingCategory != null)
                {
                    blogPost.Categories.Add(esistingCategory);
                }
            }

            blogPost = await _blogpostRepository.CreateAsync(blogPost);

            // Convert Domain to DTO
            var response = new BlogPostDto
            {
                Id = blogPost.Id,
                Title = blogPost.Title,
                ShortDescription = blogPost.ShortDescription,
                Content = blogPost.Content,
                FeaturedImageUrl = blogPost.FeaturedImageUrl,
                UrlHandle = blogPost.UrlHandle,
                PublishDate = blogPost.PublishDate,
                Author = blogPost.Author,
                IsVisible = blogPost.IsVisible,
                Categories = blogPost.Categories.Select(x => new CategoryDto
                {
                    Id = x.Id,
                    Name = x.Name,
                    UrlHandle = x.UrlHandle
                }).ToList()
            };

            return Ok();
        }

        //GET: https://localhost:7154/api/blogposts
        [HttpGet]
        public async Task<IActionResult> GetAllBlogPosts()
        {
            var blogposts = await _blogpostRepository.GetAllAsync();

            // Map DTO to Domain Model
            var response = new List<BlogPostDto>();
            {
                foreach (var blogpost in blogposts)
                {
                    response.Add(new BlogPostDto
                    {
                        Id = blogpost.Id,
                        Title = blogpost.Title,
                        ShortDescription = blogpost.ShortDescription,
                        Content = blogpost.Content,
                        FeaturedImageUrl = blogpost.FeaturedImageUrl,
                        UrlHandle = blogpost.UrlHandle,
                        PublishDate = blogpost.PublishDate,
                        Author = blogpost.Author,
                        IsVisible = blogpost.IsVisible,
                        Categories = blogpost.Categories.Select(x => new CategoryDto
                        {
                            Id = x.Id,
                            Name = x.Name,
                            UrlHandle = x.UrlHandle
                        }).ToList()
                    });
                }
            }

            return Ok(response);
        }

        //GET: https://localhost:7154/api/blogposts/{id}
        [HttpGet]
        [Route("{id:Guid}")]
        public async Task<IActionResult> GetBlogPostById([FromRoute] Guid id)
        {
            // Get BlogPost from Repository
            var exitingBlogPost = await _blogpostRepository.GetByIdAsync(id);

            if (exitingBlogPost == null)
            {
                return NotFound();
            }
            var response = new BlogPostDto
            {
                Id = exitingBlogPost.Id,
                Title = exitingBlogPost.Title,
                ShortDescription = exitingBlogPost.ShortDescription,
                Content = exitingBlogPost.Content,
                FeaturedImageUrl = exitingBlogPost.FeaturedImageUrl,
                UrlHandle = exitingBlogPost.UrlHandle,
                PublishDate = exitingBlogPost.PublishDate,
                Author = exitingBlogPost.Author,
                IsVisible = exitingBlogPost.IsVisible,
                Categories = exitingBlogPost.Categories.Select(x => new CategoryDto
                {
                    Id = x.Id,
                    Name = x.Name,
                    UrlHandle = x.UrlHandle
                }).ToList()
            };

            return Ok(response);
        }

        //GET: https://localhost:7154/api/blogposts/{urlHandle}
        [HttpGet]
        [Route("{urlHandle}")]
        public async Task<IActionResult> GetBlogPostByUrlHandle([FromRoute] string urlHandle)
        {
            // Get BlogPost details from Repository
            var exitingBlogPost = await _blogpostRepository.GetByUrlHandleAsync(urlHandle);

            if (exitingBlogPost == null)
            {
                return NotFound();
            }
            var response = new BlogPostDto
            {
                Id = exitingBlogPost.Id,
                Title = exitingBlogPost.Title,
                ShortDescription = exitingBlogPost.ShortDescription,
                Content = exitingBlogPost.Content,
                FeaturedImageUrl = exitingBlogPost.FeaturedImageUrl,
                UrlHandle = exitingBlogPost.UrlHandle,
                PublishDate = exitingBlogPost.PublishDate,
                Author = exitingBlogPost.Author,
                IsVisible = exitingBlogPost.IsVisible,
                Categories = exitingBlogPost.Categories.Select(x => new CategoryDto
                {
                    Id = x.Id,
                    Name = x.Name,
                    UrlHandle = x.UrlHandle
                }).ToList()
            };

            return Ok(response);
        }

        //PUT: https://localhost:7154/api/blogposts/{id}
        [HttpPut]
        [Route("{id:Guid}")]
        [Authorize(Roles = "Writer")]
        public async Task<IActionResult> UpdateBlogPostById([FromRoute] Guid id, UpdateBlogPostRequestDto request)
        {
            // Convert DTO to Domain Model
            var blogPost = new BlogPost
            {
                Id = id,
                Title = request.Title,
                ShortDescription = request.ShortDescription,
                Content = request.Content,
                FeaturedImageUrl = request.FeaturedImageUrl,
                UrlHandle = request.UrlHandle,
                PublishDate = request.PublishDate,
                Author = request.Author,
                IsVisible = request.IsVisible,
                Categories = new List<Category>()
            };

            foreach (var categoryGuid in request.Categories)
            {
                var esistingCategory = await _categoryRepository.GetById(categoryGuid);
                if (esistingCategory != null)
                {
                    blogPost.Categories.Add(esistingCategory);
                }
            }

            // Call Repository to Update BlogPost Domain Model
            var updatedBlogPost = await _blogpostRepository.UpdateAsync(blogPost);
            if (updatedBlogPost == null)
            {
                return NotFound();
            }

            // Convert Domain Model to DTO
            var response = new BlogPostDto
            {
                Id = blogPost.Id,
                Title = blogPost.Title,
                ShortDescription = blogPost.ShortDescription,
                Content = blogPost.Content,
                FeaturedImageUrl = blogPost.FeaturedImageUrl,
                UrlHandle = blogPost.UrlHandle,
                PublishDate = blogPost.PublishDate,
                Author = blogPost.Author,
                IsVisible = blogPost.IsVisible,
                Categories = blogPost.Categories.Select(x => new CategoryDto
                {
                    Id = x.Id,
                    Name = x.Name,
                    UrlHandle = x.UrlHandle
                }).ToList()
            };

            return Ok(response);
        }

        //DELETE: https://localhost:7154/api/blogposts/{id}
        [HttpDelete]
        [Route("{id:Guid}")]
        [Authorize(Roles = "Writer")]
        public async Task<IActionResult> DeleteBlogPsot([FromRoute] Guid id)
        {
            var deletedbBlogPost = await _blogpostRepository.DeleteAsync(id);
            if (deletedbBlogPost == null)
            {
                return NotFound();
            }

            // Convert Domain Model to DTO
            var response = new BlogPostDto
            {
                Id = deletedbBlogPost.Id,
                Title = deletedbBlogPost.Title,
                ShortDescription = deletedbBlogPost.ShortDescription,
                Content = deletedbBlogPost.Content,
                FeaturedImageUrl = deletedbBlogPost.FeaturedImageUrl,
                UrlHandle = deletedbBlogPost.UrlHandle,
                PublishDate = deletedbBlogPost.PublishDate,
                Author = deletedbBlogPost.Author,
                IsVisible = deletedbBlogPost.IsVisible
            };

            return Ok(response);
        }
    }
}

