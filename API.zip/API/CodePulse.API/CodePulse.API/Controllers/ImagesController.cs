﻿using Azure;
using CodePulse.API.Models.Domain;
using CodePulse.API.Models.DTO;
using CodePulse.API.Repositories.Interface;
using Microsoft.AspNetCore.Mvc;

namespace CodePulse.API.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ImagesController : ControllerBase
    {
        private readonly IImageRepository _imageRepository;
        public ImagesController(IImageRepository imageRepository)
        {
            _imageRepository = imageRepository;
        }
        //POST: https://localhost:7154/api/images
        [HttpPost]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadImage([FromForm] ImageUploadRequest form)
                                         //[FromForm] IFormFile file, [FromForm] string fileName, [FromForm] string title)
        {
            ValidateFileUpload(form.File);

            if (ModelState.IsValid)
            {
                //File Upload
                var blogImage = new BlogImage
                {
                    FileExtension = Path.GetExtension(form.File.FileName).ToLower(),
                    FileName = form.FileName,
                    Title = form.Title,
                    DateCreated = DateTime.Now
                };

                blogImage = await _imageRepository.Upload(form.File, blogImage);
                // Convert Domain Model to DTO
                var response = new BlogImageDto

                {
                    Id = blogImage.Id,
                    Title = blogImage.Title,
                    FileName = blogImage.FileName,
                    FileExtension = blogImage.FileExtension,
                    DateCreated = blogImage.DateCreated,
                    Url = blogImage.Url
                };
                return Ok(response);
            }

            return BadRequest(ModelState);
        }

        //GET: https://localhost:7154/api/images
        [HttpGet]
        public async Task<IActionResult> GetAllImages()
        {
            // Call image repository to get all images
            var images = await _imageRepository.GetAll();

            // Map Domain Model to DTO 
            var response = new List<BlogImageDto>();
            foreach (var image in images)
            {
                response.Add(new BlogImageDto
                {
                    Id = image.Id,
                    Title = image.Title,
                    FileName = image.FileName,
                    FileExtension = image.FileExtension,
                    DateCreated = image.DateCreated,
                    Url = image.Url
                });
            }

            return Ok(response);
        }

        private void ValidateFileUpload(IFormFile file)
        {
            var allowedExtensions = new string[] { ".jpg", ".jpeg", ".png" };
            if (!allowedExtensions.Contains(Path.GetExtension(file.FileName).ToLower()))
            {
                ModelState.AddModelError("file", "Unsupported file format");
            }

            if (file.Length > 10485760)
            {
                ModelState.AddModelError("file", "File size can't be more than 10MB");
            }
        }
    }
}
